sumUpto :: Integral a => a -> a
sumUpto x = go x 0
    where go num count
            | num == 0 = count
            | otherwise = go (num - 1) (count + num)

multiply :: Integral a => a -> a -> a
multiply x y = go x y 0
    where go num1 num2 res
            | num2 == 0 = res
            | otherwise = go num1 (num2 - 1) (res + num1)
