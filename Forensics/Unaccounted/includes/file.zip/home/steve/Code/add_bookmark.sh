#!/bin/sh

read -p "Name of the website: " name
read -p "Website: " website
[ ! -z "$name" ] && [ ! -z "$website" ] && echo $name,$website >> $HOME/.config/Bookmarks/bookmarks && notify-send "Bookmark" "$name added"
