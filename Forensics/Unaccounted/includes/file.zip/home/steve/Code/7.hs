k (x,y) = x
k1 = k((4-1), 10)

-- f :: (a, b, c) -> (d, e, f) -> ((a, d), (c, f))
-- f (a, b, c) (d, e, f) = ((a, d), (c, f))


functionC x y = 
    case z of
        True -> x
        False -> y
    where z = (x > y)

ifEvenAdd2 n =
    case z of
        True -> n
        False -> n + 2
    where z = (snd(divMod n 2) == 0)

nums x = 
    case compare x 0 of
        EQ -> 0
        LT -> -1
        GT -> 1

dodgy x y = x + y * 10
oneIsOne = dodgy 1
oneIsTwo = (flip dodgy) 2

isRight :: (Num a, Eq a) => a -> a -> a -> String
isRight a b c
    | a^2 + b^2 == c^2 = "Right triangle"
    | otherwise = "Nope, not one"

pal xs
    | xs == reverse xs = True
    | otherwise = False

g :: Char -> String
g = undefined

f :: String -> [String]
f = undefined


l :: Ord a => a -> a -> Bool
l x y
    | x > y = True
    | otherwise = False

o :: a -> a
o x = x

tensDigit :: Integral a => a -> a
tensDigit x = d
    where xlast = x `div` 10
          d = snd $ divMod xlast 10


