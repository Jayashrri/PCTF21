module Learn where

half :: Double -> Double
half x = x / 2

square :: Double -> Double
square x = x ^ 2

area :: Double -> Double
area x = pi * x * x

x = 10 * 5 + y

myResult :: Int -> Int
myResult x = x * 5

y = 10
