noFirst :: String -> String
noFirst x = tail x

rvrs :: String -> String

