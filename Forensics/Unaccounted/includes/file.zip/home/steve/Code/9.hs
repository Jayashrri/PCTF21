import Data.Char

eftEnum :: (Enum a, Ord a) => a -> a -> [a]
eftEnum from to = go to []
  where go t acc
          | t == from = t : acc
          | from < t = go (pred t) (t : acc)
          | otherwise = acc

myWords :: String -> [String]
myWords "" = []
myWords sen = 
    let 
        notSpace = (/=) ' '
        word = takeWhile notSpace sen
        rest = drop 1 . dropWhile notSpace $ sen
    in
        word : myWords rest


firstSen = "Tyger Tyget burning bright\n"
second = "second\n"
third = "third\n"
fourth = "fourth\
        \ foortj"
sen = firstSen ++ second ++ third ++ fourth

myLines :: String -> [String]
myLines "" = []
myLines sen = 
    let
        notNew = (/=) '\n'
        s = takeWhile notNew sen
        rest = drop 1 . dropWhile notNew $ sen
    in
        s : myLines rest

mySplit :: Char -> String -> [String]
mySplit _ "" = []
mySplit x y =
    let
        notStuff = (/=) x
        s = takeWhile notStuff y
        rest = drop 1 . dropWhile notStuff $ y
    in
        s : mySplit x rest

acro :: String -> String
acro a = [x | x <- a, x `elem` ['A'..'Z']]

mult3 :: [Integer] -> [Integer]
mult3 xs = filter (\x -> (rem x 3) == 0) xs

myFilter :: String -> [String]
myFilter xs = go (words xs)
    where go x = filter (\a -> (elem a ["the", "a", "an"]) == False) x

zip' :: [a] -> [b] -> [(a, b)]
zip' [] _ = []
zip' _ [] = []
zip' x y = (head x, head y) : zip' (tail x) (tail y)

zipWith' :: (a -> b -> c) -> [a] -> [b] -> [c]
zipWith' f [] _ = []
zipWith' f _ [] = []
zipWith' f x y = f (head x) (head y) : zipWith' f (tail x) (tail y)

zipWithZipWith :: [a] -> [b] -> [(a, b)]
zipWithZipWith x y = zipWith' (\x y -> (x,y)) x y

toUpperAll :: String -> String
toUpperAll "" = ""
toUpperAll x = toUpper (head x) : toUpperAll (tail x)

firstLetter = toUpper . head
