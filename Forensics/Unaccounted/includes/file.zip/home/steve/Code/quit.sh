#!/bin/sh
[ $(echo -e "No\nYes" | dmenu -i -p "Do you want to exit bspwm?") == "Yes" ] && bspc quit
